im1 = subset(baseline,Freq == 0.01 )
im2 = subset(baseline2,Freq == 0.01)
sqrt(var(im1$img_z))
sqrt(var(im2$img_z))
library(tidyverse)
library(tidyverse)
library(dplyr)

All_baseline = rbind(baseline_T[,c(1:8,11)],baseline_c[,c(1:8,11)])
All_baseline$group = c(rep("Treatment",1098),rep("Control","732"))


summary_table = All_baseline %>% group_by(group,Freq) %>% summarise(mu = mean(img_z),std = sd(img_z))

my_text1 = element_text(size = 12)
my_text2 = element_text(size = 15,face = "bold")

All_baseline$id = rep(1:30,each =61)
ggplot(data = subset(All_baseline,log(Freq)<(-1)))+aes(x = log(Freq),y = img_z)+
  geom_line(aes(group = id),color = "grey",size = 1)+ylab("Imaginary impedance [Ohm]") +
  xlab("log f [log-Hz]")+facet_wrap(~group)+
  theme(axis.text.x = my_text1)+
  theme_bw()+theme(axis.title.x = my_text2)+theme(axis.title.y = my_text2)
  
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
#+ggtitle("Baseline observations")

ggplot(data = subset(All_baseline,log(Freq)<(-3)))+aes(x = Freq,y = img_z)+
  geom_point(aes(group = id),color = "grey",size = 1)+ylab("Imaginary impedance [Ohm]") +
  xlab("Frequency [Hz]")+facet_wrap(~group)+
  theme(axis.text.x = my_text1)+theme(axis.title.x = my_text2)+theme(axis.title.y = my_text2)


ggplot(data = subset(summary_table,log(Freq)<(-3)))+aes(x = Freq,y = mu)+geom_line(aes(x = Freq,y = mu,color = group))+
  geom_ribbon(aes(ymin = mu-std, ymax = mu+std,group = group), alpha = 0.1)+ylab("Imaginary impedance [Ohm]") +
  xlab("Frequency [Hz]")+ggtitle("Baseline observations")+facet_wrap(~group)


ggplot(data = subset(summary_table,log(Freq)<(-3)))+aes(x = Freq,y = mu)+geom_point(aes(x = Freq,y = mu,color = group))+
  geom_ribbon(aes(ymin = mu-std, ymax = mu+std,group = group), alpha = 0.1)+ylab("Imaginary impedance [Ohm]") +
  xlab("Frequency [Hz]")+ggtitle("Baseline observations")

subset(summary_table,log(Freq)<(-3))

summary_table$SNR = (summary_table$mu^2)/(summary_table$std^2)

ggplot(data = subset(summary_table,log(Freq)<(-3)))+geom_point(aes(x = Freq,y = SNR,color = group))+ylab("Imaginary impedance SNR") +
  xlab("Frequency [Hz]")+ggtitle("Baseline observations")
